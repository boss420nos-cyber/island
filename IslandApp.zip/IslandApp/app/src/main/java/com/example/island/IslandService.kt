package com.example.island

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.*
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.*
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*

class IslandService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var sp: SharedPreferences
    private lateinit var wm: WindowManager
    private lateinit var holder: FrameLayout
    private lateinit var box: LinearLayout
    private lateinit var zone: View
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var time: TextView
    private lateinit var seek: SeekBar
    private lateinit var play: Button
    private lateinit var row: LinearLayout
    private lateinit var media: LinearLayout
    private var mc: MediaController? = null
    private var dragging = false
    private var y0 = 0f
    private var lastText: Pair<String, String>? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun on(k: String) = sp.getBoolean(k, true)
    private fun num(k: String, d: Int) = sp.getInt(k, d)
    private fun my() = on("mat") && Build.VERSION.SDK_INT >= 31
    private fun bgC() = if (my()) getColor(android.R.color.system_accent1_900) else Color.BLACK
    private fun fgC() = if (my()) getColor(android.R.color.system_accent1_100) else Color.WHITE
    private fun acC() = if (my()) getColor(android.R.color.system_accent1_200) else 0xFFA8C7FA.toInt()
    private fun fmt(s: Long) = "%d:%02d".format(s / 60, s % 60)

    private fun lp(w: Int, h: Int, y: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; this.y = y }

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(s: PlaybackState?) { refreshMedia(true) }
        override fun onMetadataChanged(m: MediaMetadata?) { refreshMedia(true) }
    }
    private val ticker = object : Runnable {
        override fun run() {
            refreshMedia(false)
            zone.visibility = if (on("swipe")) View.VISIBLE else View.GONE
            ui.postDelayed(this, 500)
        }
    }
    private val gone = Runnable { holder.visibility = View.GONE }
    private val hider = Runnable { anim(dp(num("w", 120))); ui.postDelayed(gone, 320) }
    private val charge = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!on("charge")) return
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            ui.post { text("charge", "⚡ جارٍ الشحن", "$l%") }
        }
    }

    override fun onServiceConnected() {
        sp = getSharedPreferences("c", 0)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        build()
        wm.addView(holder, lp(-2, -2, dp(num("y", 6))))
        zone = View(this).apply { setOnTouchListener { _, e -> swipe(e); true } }
        wm.addView(zone, lp(dp(220), dp(28), 0))
        Bus.onEvent = { k, t, s -> ui.post { if (on(k)) text(k, t, s) } }
        val f = IntentFilter(Intent.ACTION_POWER_CONNECTED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(charge, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(charge, f)
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val comp = ComponentName(this, IslandListener::class.java)
            msm.addOnActiveSessionsChangedListener({ pick(it) }, comp)
            pick(msm.getActiveSessions(comp))
        } catch (e: SecurityException) { /* فعّل إذن الإشعارات */ }
        ui.post(ticker)
    }

    private fun pick(list: List<MediaController>?) {
        mc?.unregisterCallback(cb)
        mc = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        mc?.registerCallback(cb)
        refreshMedia(true)
    }

    private fun build() {
        title = TextView(this).apply { textSize = 14f; maxLines = 1 }
        sub = TextView(this).apply { textSize = 12f; maxLines = 1; alpha = .75f }
        time = TextView(this).apply { textSize = 11f; alpha = .75f }
        seek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) time.text = fmt(p.toLong()) }
                override fun onStartTrackingTouch(s: SeekBar) { dragging = true; ui.removeCallbacks(hider) }
                override fun onStopTrackingTouch(s: SeekBar) {
                    mc?.transportControls?.seekTo(s.progress * 1000L); dragging = false
                    ui.postDelayed(hider, num("hide", 5) * 1000L)
                }
            })
        }
        fun b(t: String, f: () -> Unit) = Button(this).apply { text = t; textSize = 18f; minWidth = 0; setOnClickListener { f() } }
        play = b("⏯") {
            mc?.let { if (it.playbackState?.state == PlaybackState.STATE_PLAYING) it.transportControls.pause() else it.transportControls.play() }
        }
        row = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(b("⏮") { mc?.transportControls?.skipToPrevious() })
            addView(play)
            addView(b("⏭") { mc?.transportControls?.skipToNext() })
        }
        media = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(seek); addView(time); addView(row) }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(title); addView(sub); addView(media)
        }
        holder = FrameLayout(this).apply {
            visibility = View.GONE
            addView(box, FrameLayout.LayoutParams(dp(120), -2, Gravity.CENTER_HORIZONTAL))
        }
    }

    private fun style() {
        box.background = GradientDrawable().apply { setColor(bgC()); cornerRadius = dp(28).toFloat() }
        box.minimumHeight = dp(num("h", 36))
        for (t in listOf(title, sub, time)) t.setTextColor(fgC())
        seek.progressTintList = ColorStateList.valueOf(acC())
        seek.thumbTintList = ColorStateList.valueOf(acC())
        for (i in 0 until row.childCount) (row.getChildAt(i) as Button).apply { setBackgroundColor(0); setTextColor(acC()) }
    }

    private fun anim(to: Int) {
        ValueAnimator.ofInt(box.layoutParams.width, to).apply {
            duration = 300
            addUpdateListener { box.layoutParams = box.layoutParams.apply { width = it.animatedValue as Int } }
            start()
        }
    }

    private fun open(wDp: Int, hideMs: Long) {
        ui.removeCallbacks(hider); ui.removeCallbacks(gone)
        style()
        val p = holder.layoutParams as WindowManager.LayoutParams
        p.y = dp(num("y", 6)); wm.updateViewLayout(holder, p)
        holder.visibility = View.VISIBLE
        anim(dp(wDp))
        ui.postDelayed(hider, hideMs)
    }

    private fun text(k: String, t: String, s: String) {
        lastText = t to s
        media.visibility = View.GONE; title.text = t; sub.text = s
        open(if (k == "call") 290 else 260, if (k == "call") 30000 else num("hide", 5) * 1000L)
    }

    private fun showMusic() {
        val md = mc?.metadata
        title.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        sub.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        media.visibility = View.VISIBLE
        open(300, num("hide", 5) * 1000L)
    }

    private fun refreshMedia(announce: Boolean) {
        val c = mc ?: return
        val st = c.playbackState ?: return
        val dur = (c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L) / 1000
        val pos = if (st.state == PlaybackState.STATE_PLAYING)
            (st.position + (SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong() / 1000
        else st.position / 1000
        if (announce && on("music") && st.state == PlaybackState.STATE_PLAYING) showMusic()
        seek.max = dur.toInt()
        if (!dragging) { seek.progress = pos.toInt(); time.text = "${fmt(pos)} / ${fmt(dur)}" }
        play.text = if (st.state == PlaybackState.STATE_PLAYING) "⏸" else "▶"
    }

    private fun swipe(e: MotionEvent) {
        if (e.action == MotionEvent.ACTION_DOWN) y0 = e.rawY
        else if (e.action == MotionEvent.ACTION_MOVE && e.rawY - y0 > dp(24)) {
            y0 = Float.MAX_VALUE
            if (mc?.metadata != null && on("music")) showMusic()
            else { val l = lastText; if (l != null) text("notif", l.first, l.second) else text("notif", "لا يوجد نشاط", "") }
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        Bus.onEvent = null; ui.removeCallbacksAndMessages(null)
        unregisterReceiver(charge); wm.removeView(holder); wm.removeView(zone)
        super.onDestroy()
    }
}
