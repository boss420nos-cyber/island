package com.example.island

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val sp by lazy { getSharedPreferences("c", 0) }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 100, 40, 40) }
        fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        fun sw(t: String, k: String) = l.addView(Switch(this).apply {
            text = t; isChecked = sp.getBoolean(k, true)
            setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(k, v).apply() }
        })
        fun sb(t: String, k: String, mn: Int, mx: Int, d: Int) {
            val tv = TextView(this).apply { text = "$t: ${sp.getInt(k, d)}" }
            l.addView(tv)
            l.addView(SeekBar(this).apply {
                max = mx - mn; progress = sp.getInt(k, d) - mn
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                        sp.edit().putInt(k, p + mn).apply(); tv.text = "$t: ${p + mn}"
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            })
        }
        btn("1) تفعيل خدمة إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2) السماح بالوصول إلى الإشعارات") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        btn("تجربة الجزيرة") { Bus.onEvent?.invoke("notif", "تجربة", "الجزيرة تعمل") }
        sw("ألوان Material You", "mat"); sw("السحب للأسفل تحت الكاميرا", "swipe")
        sw("الإشعارات", "notif"); sw("المكالمات", "call"); sw("المؤقّت", "timer")
        sw("الشحن", "charge"); sw("الموسيقى", "music")
        sb("المسافة من الأعلى (dp)", "y", 0, 60, 6)
        sb("عرض الكبسولة (dp)", "w", 60, 200, 120)
        sb("ارتفاع الكبسولة (dp)", "h", 24, 60, 36)
        sb("مدة الظهور (ثانية)", "hide", 2, 15, 5)
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
