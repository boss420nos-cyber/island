package com.example.island

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object Bus { var onEvent: ((kind: String, title: String, text: String) -> Unit)? = null }

class IslandListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        if (sbn.packageName == packageName || n.category == Notification.CATEGORY_TRANSPORT) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val t = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val s = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val kind = when (n.category) {
            Notification.CATEGORY_CALL -> "call"
            Notification.CATEGORY_ALARM, Notification.CATEGORY_PROGRESS -> "timer"
            else -> "notif"
        }
        Bus.onEvent?.invoke(kind, t, s)
    }
}
